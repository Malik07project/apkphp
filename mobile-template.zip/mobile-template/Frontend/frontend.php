<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAUNDRY</title>
    <link rel="stylesheet" href="frontend.css">
    <!--bootstap-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <!--bootstap-->
</head>

<body>
    <!--nav-->
    <div class="row g-0 text-center">
        <div class="col-sm-6 col-md-12">
            <nav class="navbar bg-body-tertiary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <img src="https://i.pinimg.com/originals/75/ae/0b/75ae0bcba2cac8d7289114883dea1f74.png"
                            alt="Logo" width="50" height="50" class="d-inline-block align-text-top">
                        <h3>LAUNDRY</h3>
                    </a>
                </div>
            </nav>
        </div>
        <!--COLUMN 2-->
        <div class="col-6 col-md-12">
            <div class="container-xxl">

                <div class="container-1 text-center">
                    <div class="row">
                        <div class="col">
                            <img src="https://i.pinimg.com/originals/75/ae/0b/75ae0bcba2cac8d7289114883dea1f74.png"
                                class="img-fluid" alt="...">
                        </div>
                        <div class="col">
                            <td class="lign-middle aalign-items-center">
                                <h3>LAUNDR YUK !</h3>
                                <p>"Tampilan Segar, Pakaian Lebih Bersinar! Gunakan Layanan Laundry Profesional Kami
                                    Hari
                                    Ini!"</p>
                            </td>



                        </div>
                    </div>
                </div>
            </div>
            <!--nav-->


            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>