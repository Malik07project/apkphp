<?php
session_start();
include "koneksi.php";
?>
<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>
        Admin perpustakaan ITBA DCC
    </title>
    <link rel="stylesheet" href="css/bt-1.css">

    <!-- manifest meta -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="manifest" href="manifest.json" />

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="images/logo.png" sizes="180x180">
    <link rel="icon" href="images/logo.png" sizes="32x32" type="image/png">
    <link rel="icon" href="images/logo.png" sizes="16x16" type="image/png">

    <!-- Material icons-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">

    <!-- swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style-blue.css" rel="stylesheet" id="style">


    <link rel="stylesheet" href="css/hover-main.css">



    <style>
        body {
            background: #f5f5f5;
            margin: 0;
            padding: 20px 0 0 0;
            text-align: center;
            font-size: 16px;
        }

        h1 {
            color: #222;
            font-size: 24px;
        }
    </style>

</head>

<body class="body-scroll d-flex flex-column h-100 menu-overlay" data-page="homepage">
    <!-- screen loader -->
    <div class="container-fluid h-100 loader-display">
        <div class="row h-100">
            <div class="align-self-center col">
                <div class="logo-loading">
                    <div class="icon icon-100 mb-4 rounded-circle">
                        <img src="images/no_image.png" alt="" class="w-100">
                    </div>
                    <h4 class="text-default">LAUNDRY BANDAR LAMPUNG !</h4>
                    <p class="text-secondary">Bring You To The World Class</p>
                    <div class="loader-ellipsis">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-menu">
        <div class="row mb-4 no-gutters">
            <div class="col-auto"><button class="btn btn-link btn-40 btn-close text-white"><span
                        class="material-icons">chevron_left</span></button></div>
            <div class="col-auto">
                <div class="avatar avatar-40 rounded-circle position-relative">
                    <figure class="background">
                        <img src="images/logo.png" width="50px" alt="">
                    </figure>
                </div>
            </div>
            <div class="col pl-3 text-left align-self-center">
                <h6 class="mb-1">
                    <?php
                    echo $_SESSION["nama lengkap"];
                    ?>
                </h6>
                <p class="small text-default-secondary">Administrator</p>
            </div>
        </div>
        <div class="menu-container">


            <ul class="nav nav-pills flex-column ">
                <li class="nav-item">
                    <a class="nav-link active" href="">
                        <div>
                            <span class="material-icons icon">account_balance</span>
                            Dashboard
                        </div>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategori.php">
                        <div>
                            <span class="material-icons icon">perm_contact_calendar</span>
                            kategori
                        </div>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="main.php">
                        <div>
                            <span class="material-icons icon">lock</span>
                            Buku
                        </div>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="Frontend/table.html">
                        <div>
                            <span class="material-icons icon">settings</span>
                            settings
                        </div>
                    </a>
                </li>

                <!-- <li class="nav-item">
                    <a class="nav-link" href="Frontend/frontend.php">
                        <div>
                            <span class="material-icons icon">FRONTEND</span>
                            FRONTEND
                        </div>
                    </a>
                </li> -->

            </ul>
            <div class="text-center">
                <a href="signout.php" class="btn btn-outline-danger text-white rounded my-3 mx-auto">Sign out</a>
            </div>
        </div>
    </div>

    <!-- menu main -->




    <div class="backdrop"></div>



    <!-- Begin page content -->
    <main class="flex-shrink-0 main has-footer">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <button class="menu-btn btn btn-40 btn-link" type="button">
                        <span class="material-icons">menu</span>
                    </button>
                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">LAUNDRY</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto pl-0">

                    <font color="#ffffff">Malik</font>



                    <a href="index.html" class="avatar avatar-30 shadow-sm rounded-circle ml-2">

                        <figure class="m-0 background">
                            <img src="images/no_image.png" width="70px" alt="">
                        </figure>
                    </a>
                </div>
            </div>
        </header>


        <div class="main-container">
            <!-- page content start -->

            <div class="container mb-4 text-center">
                <div class="card bg-default-secondary shadow-default">
                    <div class="card-body">
                        <!-- Swiper -->
                        <div class="swiper-container addsendcarousel text-left">
                            Halo, User
                        </div>
                    </div>
                </div>
            </div>
            <!-- Swiper -->




            <!-- PWA add to home display -->

            <!-- PWA add to home display -->




            <div class="container ">

                <div class="row text-center mt-3">
                    <div class="col-4 col-md-3">
                        <div class="card border-0 mb-4">
                            <div class="card-body">
                                <a href="home.php?open=Kategori">
                                    <div class="avatar avatar-60 bg-default-light rounded-circle text-default">
                                        <i class="material-icons vm md-36 text-template">inventory</i>
                                    </div>
                                </a>
                                <h3 class="mt-3 mb-0 font-weight-normal"></h3>
                                <p class="text-secondary small">kategori</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 col-md-3">
                        <div class="card border-0 mb-4">
                            <div class="card-body">
                                <a href="home.php?open=buku">
                                    <div class="avatar avatar-60 bg-default-light rounded-circle text-default">
                                        <i class="material-icons vm md-36 text-template">list</i>
                                    </div>
                                </a>
                                <h3 class="mt-3 mb-0 font-weight-normal"></h3>
                                <p class="text-secondary small">Buku</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 col-md-3">
                        <div class="card border-0 mb-4">
                            <div class="card-body">
                                <a href="home.php?open=anggota">
                                    <div class="avatar avatar-60 bg-default-light rounded-circle text-default">
                                        <i class="material-icons vm md-36 text-template">add_shopping_cart</i>
                                    </div>
                                </a>
                                <h3 class="mt-3 mb-0 font-weight-normal"></h3>
                                <p class="text-secondary small">Anggota</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 col-md-3">
                        <div class="card border-0 mb-4">
                            <div class="card-body">
                                <a href="home.php?open=Laporan">
                                    <div class="avatar avatar-60 bg-default-light rounded-circle text-default">
                                        <i class="material-icons vm md-36 text-template">account_circle</i>
                                    </div>
                                </a>
                                <h3 class="mt-3 mb-0 font-weight-normal"></h3>
                                <p class="text-secondary small">Laporan</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
    </main>

    <!-- footer-->
    <div class="footer">
        <div class="row no-gutters justify-content-center">
            <div class="col-auto">
                <a href="table.html" class="active">
                    <i class="material-icons">home</i>
                    <p>Home</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="table.html" class="">
                    <i class="material-icons">add_shopping_cart</i>
                    <p>Menu 1</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="list.html" class="">
                    <i class="material-icons">shopping_cart</i>
                    <p>Menu 2</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="table.html" class="">
                    <i class="material-icons">inventory</i>
                    <p>Menu 3</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="table.html" class="">
                    <i class="material-icons">account_circle</i>
                    <p>Menu 3</p>
                </a>
            </div>
        </div>
    </div>


    <!-- color settings style switcher -->





    <!-- Required jquery and libraries -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- cookie js -->
    <script src="js/jquery.cookie.js"></script>

    <!-- Swiper slider  js-->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Customized jquery file  -->
    <script src="js/main.js"></script>
    <script src="js/color-scheme-demo.js"></script>

    <!-- PWA app service registration and works -->
    <script src="js/pwa-services.js"></script>

    <!-- page level custom script -->
    <script src="js/app.js"></script>



</body>

</html>