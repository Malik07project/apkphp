<?php
session_start();
include "koneksi.php";
?>
<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>
        Admin perpustakaan ITBA DCC
    </title>

    <!-- manifest meta -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="manifest" href="manifest.json" />

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="images/logo.png" sizes="180x180">
    <link rel="icon" href="images/logo.png" sizes="32x32" type="image/png">
    <link rel="icon" href="images/logo.png" sizes="16x16" type="image/png">

    <!-- Material icons-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">

    <!-- swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" id="style">




</head>

<body class="body-scroll d-flex flex-column h-100 menu-overlay" data-page="homepage">
    <!-- screen loader -->
    <?php
    if (isset($_GET['open'])) {
        switch ($_GET['open']) {
            case "Kategori":
                if (!file_exists("modul/Kategori/tampil.php"))
                    die("maaf halaman kosong");
                include "modul/Kategori/tampil.php";
                break;
            case "Kategori-Form";
                if (!file_exists("modul/Kategori/form.php"))
                    die("maaf halaman kosong");
                include "modul/Kategori/form.php";
                break;
        }
    }
    ?>


    <?php
    if (isset($_GET['open'])) {
        switch ($_GET['open']) {
            case "anggota":
                if (!file_exists("modul/anggota/tampil.php"))
                    die("maaf halaman kosong");
                include "modul/anggota/tampil.php";
                break;
            case "anggota-Form";
                if (!file_exists("modul/anggota/form.php"))
                    die("maaf halaman kosong");
                include "modul/anggota/form.php";
                break;




        }
    }
    ?>


    <?php
    if (isset($_GET['open'])) {
        switch ($_GET['open']) {
            case "buku":
                if (!file_exists("modul/buku/tampil.php"))
                    die("maaf halaman kosong");
                include "modul/buku/tampil.php";
                break;
            case "buku-Form";
                if (!file_exists("modul/buku/form.php"))
                    die("maaf halaman kosong");
                include "modul/buku/form.php";
                break;
        }
    }
    ?>

    <?php
    if (isset($_GET['open'])) {
        switch ($_GET['open']) {
            case "Laporan":
                if (!file_exists("modul/Laporan/tampil.php"))
                    die("maaf halaman kosong");
                include "modul/Laporan/tampil.php";
                break;
            case "buku-Form";
                if (!file_exists("modul/Laporan/form.php"))
                    die("maaf halaman kosong");
                include "modul/Laporan/form.php";
                break;
        }
    }
    ?>



    <!-- color settings style switcher -->





    <!-- Required jquery and libraries -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- cookie js -->
    <script src="js/jquery.cookie.js"></script>

    <!-- Swiper slider  js-->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Customized jquery file  -->
    <script src="js/main.js"></script>
    <script src="js/color-scheme-demo.js"></script>

    <!-- PWA app service registration and works -->
    <script src="js/pwa-services.js"></script>

    <!-- page level custom script -->
    <script src="js/app.js"></script>



</body>

</html>