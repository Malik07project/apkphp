<?php
if ($_GET['form'] == 'add') {

    $query = mysqli_query($koneksidb, "SELECT max(kode_buku) as maxKode FROM buku")
        or die('Query salah : ' . mysqli_error($koneksidb));
    $data = mysqli_fetch_assoc($query);

    $kode_buku = $data['maxKode'];

    $noUrut = substr($kode_buku, 4, 3);
    $noUrut++;

    $singkatan = "BK-";

    $query2 = mysqli_query($koneksidb, "SELECT * FROM buku")
        or die('Query salah : ' . mysqli_error($koneksidb));
    $jumlah = mysqli_num_rows($query2);

    if ($jumlah != 0) {
        $kode = $singkatan . sprintf("%03s", $noUrut);
    } else {
        $kode = 'BK-001';
    }

    ?>

    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <a href="home.php?open=buku">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">keyboard_arrow_left</span>
                        </button>
                    </a>

                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Tambah buku</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">

                </div>
            </div>
        </header>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">

                <?php
                if (isset($_POST['btnSimpan'])) {
                    $random = (rand() % 999);

                    $kode_buku = addslashes($_POST["kode_buku"]);
                    $judul = addslashes($_POST["judul"]);
                    $kode_kategori = addslashes($_POST["kode_kategori"]);

                    $query = mysqli_query($koneksidb, "INSERT INTO buku (kode_buku,judul,kode_kategori)
            VALUES('$kode_buku','$judul','$kode_kategori')")
                        or die('Insert salah : ' . mysqli_error($koneksidb));

                    if ($query) {
                        echo "<meta http-equiv='refresh' content='0; url=home.php?open=buku-Form&form=add&alert=1'>";
                    }





                }

                # TAMPILKAN DATA KE FORM
                $dataNama = isset($_POST['judul']) ? $_POST['judul'] : '';
                $dataNama = isset($_POST['kode_kategori']) ? $_POST['$kode_kategori'] : '';
                ?>


                <?php
                if (empty($_GET['alert'])) {
                    echo "";
                } elseif ($_GET['alert'] == 1) {
                    ?>
                    <div class="alert alert-success">Data berhasil di simpan.</div>
                    <?php
                }
                ?>


                <div class="card">
                    <form role="form" id="form1" name="form1" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                        enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group float-label active">
                                <input type="text" name="kode_buku" value="<?php echo $kode; ?>" readonly
                                    class="form-control">
                                <label class="form-control-label">Kode buku</label>
                            </div>

                            <div class="form-group float-label active">
                                <input type="text" name="judul" maxlength="50" class="form-control" required>
                                <label class="form-control-label">Nama buku</label>
                            </div>

                            <div class="form-group float-label active">
                                <select name="kode_kategori" class="form-control" required>
                                    <option value="">- Pilih -</option>

                                    <?php
                                    $query = mysqli_query($koneksidb, "SELECT * FROM kategori ORDER BY Kode_Kategori ASC")
                                        or die('Query salah : ' . mysqli_error($koneksidb));
                                    while ($myData = mysqli_fetch_assoc($query)) {
                                        ?>
                                        <option value="<?php echo $myData['Kode_Kategori']; ?>">
                                            <?php echo $myData['Nama_Kategori']; ?>
                                        </option>
                                    <?php } ?>
                                </select>


                                <label class="form-control-label">Nama_kategori</label>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="btnSimpan" value="Save" class="btn btn-block btn-default rounded"><i
                                    class="fa fa-save"></i> Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php
} elseif ($_GET['form'] == 'edit') {
    if (isset($_GET['kode_buku'])) {

        $query = mysqli_query($koneksidb, "SELECT * FROM buku
										WHERE kode_buku='$_GET[kode_buku]'")
            or die('Query salah : ' . mysqli_error($koneksidb));
        $myData = mysqli_fetch_assoc($query);
    }
    ?>

    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <a href="home.php?open=buku">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">keyboard_arrow_left</span>
                        </button>
                    </a>

                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Detail buku</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">

                </div>
            </div>
        </header>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">

                <?php
                if (isset($_POST['btnEdit'])) {
                    $random = (rand() % 999);

                    $kode_buku = addslashes($_POST["kode_buku"]);
                    $judul = addslashes($_POST["judul"]);

                    $query = mysqli_query($koneksidb, "UPDATE buku SET judul='$judul'
													WHERE kode_buku='$kode_buku'")
                        or die('Insert salah : ' . mysqli_error($koneksidb));

                    if ($query) {
                        echo "<meta http-equiv='refresh' content='0; url=home.php?open=buku-Form&form=edit&kode_buku=$kode_buku&alert=2'>";
                    }
                }

                # TAMPILKAN DATA KE FORM
                $dataNama = isset($_POST['judul']) ? $_POST['judul'] : '';
                ?>


                <?php
                if (empty($_GET['alert'])) {
                    echo "";
                } elseif ($_GET['alert'] == 2) {
                    ?>
                    <div class="alert alert-success">Data berhasil di update.</div>
                    <?php
                }
                ?>


                <div class="card">
                    <form role="form" id="form1" name="form1" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                        enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group float-label active">
                                <input type="text" name="kode_buku" value="<?php echo $myData['kode_buku']; ?>" readonly
                                    class="form-control">
                                <label class="form-control-label">Kode buku</label>
                            </div>
                            <div class="form-group float-label active">
                                <input type="hidden" name="kode_buku" value="<?php echo $myData['kode_buku']; ?>"
                                    class="form-control">

                                <input type="text" name="judul" maxlength="50" value="<?php echo $myData['judul']; ?>"
                                    class="form-control" required>
                                <label class="form-control-label">Nama buku</label>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="btnEdit" value="Save" class="btn btn-block btn-default rounded"><i
                                    class="fa fa-save"></i> Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php
}
?>