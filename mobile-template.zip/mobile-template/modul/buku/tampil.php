<main class="flex-shrink-0 main">
    <!-- Fixed navbar -->
    <header class="header">
        <div class="row">
            <div class="col-auto px-0">
                <a href="main.php?open=Dashboard">
                    <button class="btn btn-40" type="button">
                        <span class="material-icons text-white">keyboard_arrow_left</span>
                    </button>
                </a>
            </div>
            <div class="text-left col align-self-center">
                <a class="navbar-brand" href="#">
                    <h5 class="mb-0">Tambah Buku</h5>
                </a>
            </div>
            <div class="ml-auto col-auto">
            </div>
        </div>
    </header>

    <!-- page content start -->
    <div class="main-container">
        <div class="container">
            <div class="card mb-3">
                <div class="card-body">
                    <?php
                    $query = mysqli_query($koneksidb, "
                    SELECT * FROM buku,kategori 
                    WHERE buku.kode_kategori = kategori.Kode_Kategori ORDER BY kode_buku ASC")
                        or die('Query salah : ' . mysqli_error($koneksidb));
                    $nomor = 0;
                    while ($myData = mysqli_fetch_assoc($query)) {
                        $nomor++;
                        ?>
                        <div class="media">
                            <div class="media-body">
                                <p class="small text-secondary mb-1">Kode : <?php echo $myData['kode_buku']; ?></p>
                                <a href="?open=buku-Form&form=edit&kode_buku=<?php echo $myData['kode_buku']; ?>">
                                    <h6 class="mb-1 text-default">Judul : <?php echo $myData['judul']; ?></h6>
                                </a>
                                <p class="small text-secondary mb-1">Kode_kategori :
                                    <?php echo $myData['kode_kategori']; ?> - <?php echo $myData['Nama_Kategori']; ?>
                                </p>
                            </div>
                            <div class="col-auto">
                                <a href="modul/buku/proses.php?act=delete&kode_buku=<?php echo $myData['kode_buku']; ?>"
                                    onclick="return confirm('Yakin mau di hapus ?');"><i
                                        class="material-icons text-danger">delete_forever</i></a>
                            </div>
                        </div>
                        <hr>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="footer no-bg-shadow py-3">
    <div class="row justify-content-center">
        <div class="col">
        </div>
        <div class="col">
            <div align="right"><a href="?open=buku-Form&form=add" class="btn btn-default btn-40 rounded-circle">+</a>
            </div>
        </div>
    </div>
</div>