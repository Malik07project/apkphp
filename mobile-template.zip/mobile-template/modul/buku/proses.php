<?php
session_start();

include_once "../../koneksi.php";
date_default_timezone_set('Asia/Jakarta');

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=../../index.php?alert=3'>";
} else {
    if ($_GET['act'] == 'delete') {
        if (isset($_GET['kode_buku'])) {
            $kode_buku = $_GET['kode_buku'];

            $query = mysqli_query($koneksidb, "DELETE FROM buku WHERE kode_buku='$kode_buku'")
                or die('Delete salah : ' . mysqli_error($koneksidb));

            if ($query) {
                header("location: ../../home.php?open=buku");
            }

        }
    }
}
?>