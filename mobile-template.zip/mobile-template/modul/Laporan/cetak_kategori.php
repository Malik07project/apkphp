<h3>
    <center>
        LAUNDRY BANDAR LAMPUNG<br>
        LAPORAN LAUNDRY BANDAR LAMPUNG
    </center>
</h3>

<table border="1" width="100%">
    <tr>
        <th>Nomor</th>
        <th>Kode Kategori</th>
        <th>Nama Kategori</th>
    </tr>
    <?php
    include "../../koneksi.php";
    $query = mysqli_query($koneksidb, "select * from Kategori");
    $nomor;
    while ($data = mysqli_fetch_array($query)) {
        $nomor++;
        ?>
        <tr>
            <td><?php echo $nomor; ?></td>
            <td><?php echo $data['Kode_Kategori']; ?></td>
            <td><?php echo $data['Nama_Kategori']; ?></td>
        </tr>
    <?php } ?>
</table>

<br>
Bandar Lampung, <?php echo date('d M Y'); ?>
<br>Pemilik Laundry.!<br><br><br><br>
(Abdul Malik Mubaroq)