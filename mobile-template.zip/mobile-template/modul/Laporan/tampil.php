<main class="flex-shrink-0 main">
    <!-- Fixed navbar -->
    <header class="header">
        <div class="row">
            <div class="col-auto px-0">
                <a href="main.php?open=Dashboard">
                    <button class="btn btn-40" type="button">
                        <span class="material-icons text-white">keyboard_arrow_left</span>
                    </button>
                </a>
            </div>
            <div class="text-left col align-self-center">
                <a class="navbar-brand" href="#">
                    <h5 class="mb-0">Menu Laporan</h5>
                </a>
            </div>
            <div class="ml-auto col-auto">

            </div>
        </div>
    </header>

    <!-- page content start -->

    <div class="main-container">
        <div class="container">
            <div class="card mb-3">


                <div class="card-body">

                    <div class="media">
                        <div class="media-body">
                            <a href="modul/Laporan/cetak_kategori.php" target="_blank">
                                <h6 class="mb-1 text-default">laporan Data Kategori</h6>
                            </a>
                        </div>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
    </div>
</main>