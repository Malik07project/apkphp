<?php
if ($_GET['form'] == 'add') {

    $query = mysqli_query($koneksidb, "SELECT max(Kode_Kategori) as maxKode FROM Kategori")
        or die('Query salah : ' . mysqli_error($koneksidb));
    $data = mysqli_fetch_assoc($query);

    $Kode_Kategori = $data['maxKode'];

    $noUrut = substr($Kode_Kategori, 4, 3);
    $noUrut++;

    $singkatan = "KT-";

    $query2 = mysqli_query($koneksidb, "SELECT * FROM Kategori")
        or die('Query salah : ' . mysqli_error($koneksidb));
    $jumlah = mysqli_num_rows($query2);

    if ($jumlah != 0) {
        $kode = $singkatan . sprintf("%03s", $noUrut);
    } else {
        $kode = 'KT-001';
    }

    ?>

    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <a href="home.php?open=Kategori">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">keyboard_arrow_left</span>
                        </button>
                    </a>

                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Tambah Kategori</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">
                    <a href="home.php?open=Kategori-Form&form=delete&Kode_Kategori=<?php echo $kode; ?>">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">delete</span>
                        </button>
                    </a>
                </div>
            </div>
        </header>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">

                <?php
                if (isset($_POST['btnSimpan'])) {
                    $random = (rand() % 999);

                    $Kode_Kategori = addslashes($_POST["Kode_Kategori"]);
                    $Nama_Kategori = addslashes($_POST["Nama_Kategori"]);

                    $query = mysqli_query($koneksidb, "INSERT INTO Kategori (Kode_Kategori,Nama_Kategori)
            VALUES('$Kode_Kategori','$Nama_Kategori')")
                        or die('Insert salah : ' . mysqli_error($koneksidb));

                    if ($query) {
                        echo "<meta http-equiv='refresh' content='0; url=home.php?open=Kategori-Form&form=add&alert=1'>";
                    }





                }

                # TAMPILKAN DATA KE FORM
                $dataNama = isset($_POST['Nama_Kategori']) ? $_POST['Nama_Kategori'] : '';
                ?>


                <?php
                if (empty($_GET['alert'])) {
                    echo "";
                } elseif ($_GET['alert'] == 1) {
                    ?>
                    <div class="alert alert-success">Data berhasil di simpan.</div>
                    <?php
                }
                ?>


                <div class="card">
                    <form role="form" id="form1" name="form1" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                        enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group float-label active">
                                <input type="text" name="Kode_Kategori" value="<?php echo $kode; ?>" readonly
                                    class="form-control">
                                <label class="form-control-label">Kode Kategori</label>
                            </div>

                            <div class="form-group float-label active">
                                <input type="text" name="Nama_Kategori" maxlength="50" class="form-control" required>
                                <label class="form-control-label">Nama Kategori</label>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="btnSimpan" value="Save" class="btn btn-block btn-default rounded"><i
                                    class="fa fa-save"></i> Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php
} elseif ($_GET['form'] == 'edit') {
    if (isset($_GET['Kode_Kategori'])) {

        $query = mysqli_query($koneksidb, "SELECT * FROM Kategori
										WHERE Kode_Kategori='$_GET[Kode_Kategori]'")
            or die('Query salah : ' . mysqli_error($koneksidb));
        $myData = mysqli_fetch_assoc($query);
    }
    ?>

    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <a href="home.php?open=Kategori">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">keyboard_arrow_left</span>
                        </button>
                    </a>

                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Detail Kategori</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">
                    <a href="home.php?open=Kategori-Form&form=delete&Kode_Kategori=<?php echo $myData['Kode_Kategori']; ?>">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">delete</span>
                        </button>
                    </a>
                </div>
            </div>
        </header>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">

                <?php
                if (isset($_POST['btnEdit'])) {
                    $random = (rand() % 999);

                    $Kode_Kategori = addslashes($_POST["Kode_Kategori"]);
                    $Nama_Kategori = addslashes($_POST["Nama_Kategori"]);

                    $query = mysqli_query($koneksidb, "UPDATE Kategori SET Nama_Kategori='$Nama_Kategori'
													WHERE Kode_Kategori='$Kode_Kategori'")
                        or die('Insert salah : ' . mysqli_error($koneksidb));

                    if ($query) {
                        echo "<meta http-equiv='refresh' content='0; url=home.php?open=Kategori-Form&form=edit&Kode_Kategori=$Kode_Kategori&alert=2'>";
                    }
                }

                # TAMPILKAN DATA KE FORM
                $dataNama = isset($_POST['Nama_Kategori']) ? $_POST['Nama_Kategori'] : '';
                ?>


                <?php
                if (empty($_GET['alert'])) {
                    echo "";
                } elseif ($_GET['alert'] == 2) {
                    ?>
                    <div class="alert alert-success">Data berhasil di update.</div>
                    <?php
                }
                ?>


                <div class="card">
                    <form role="form" id="form1" name="form1" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                        enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group float-label active">
                                <input type="text" name="Kode_Kategori" value="<?php echo $myData['Kode_Kategori']; ?>"
                                    readonly class="form-control">
                                <label class="form-control-label">Kode Kategori</label>
                            </div>
                            <div class="form-group float-label active">
                                <input type="hidden" name="Kode_Kategori" value="<?php echo $myData['Kode_Kategori']; ?>"
                                    class="form-control">

                                <input type="text" name="Nama_Kategori" maxlength="50"
                                    value="<?php echo $myData['Nama_Kategori']; ?>" class="form-control" required>
                                <label class="form-control-label">Nama Kategori</label>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="btnEdit" value="Save" class="btn btn-block btn-default rounded"><i
                                    class="fa fa-save"></i> Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php
}
?>