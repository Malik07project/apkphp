<?php
session_start();

include_once "../../koneksi.php";
date_default_timezone_set('Asia/Jakarta');

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=../../index.php?alert=3'>";
} else {
    if ($_GET['act'] == 'delete') {
        if (isset($_GET['kodeanggota'])) {
            $kodeanggota = $_GET['kodeanggota'];

            $query = mysqli_query($koneksidb, "DELETE FROM anggota WHERE kodeanggota='$kodeanggota'")
                or die('Delete salah : ' . mysqli_error($koneksidb));

            if ($query) {
                header("location: ../../home.php?open=anggota");
            }

        }
    }
}
?>