<?php
if ($_GET['form'] == 'add') {

    $query = mysqli_query($koneksidb, "SELECT max(kodeanggota) as maxKode FROM anggota")
        or die('Query salah : ' . mysqli_error($koneksidb));
    $data = mysqli_fetch_assoc($query);

    $kodeanggota = $data['maxKode'];

    $noUrut = substr($kodeanggota, 4, 3);
    $noUrut++;

    $singkatan = "AG-";

    $query2 = mysqli_query($koneksidb, "SELECT * FROM anggota")
        or die('Query salah : ' . mysqli_error($koneksidb));
    $jumlah = mysqli_num_rows($query2);

    if ($jumlah != 0) {
        $kode = $singkatan . sprintf("%03s", $noUrut);
    } else {
        $kode = 'AG-001';
    }

    ?>

    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <a href="home.php?open=anggota">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">keyboard_arrow_left</span>
                        </button>
                    </a>

                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Tambah anggota</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">
                    <a href="home.php?open=anggota-Form&form=delete&kodeanggota=<?php echo $kode; ?>">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">delete</span>
                        </button>
                    </a>
                </div>
            </div>
        </header>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">

                <?php
                if (isset($_POST['btnSimpan'])) {
                    $random = (rand() % 999);

                    $kodeanggota = addslashes($_POST["kodeanggota"]);
                    $namaanggota = addslashes($_POST["namaanggota"]);
                    $alamat = addslashes($_POST["alamat"]);

                    $query = mysqli_query($koneksidb, "INSERT INTO anggota (kodeanggota,namaanggota,alamat)
            VALUES('$kodeanggota','$namaanggota','$alamat')")
                        or die('Insert salah : ' . mysqli_error($koneksidb));

                    if ($query) {
                        echo "<meta http-equiv='refresh' content='0; url=home.php?open=anggota-Form&form=add&alert=1'>";
                    }





                }

                # TAMPILKAN DATA KE FORM
                $dataNama = isset($_POST['namaanggota']) ? $_POST['namaanggota'] : '';
                $dataNama = isset($_POST['alamat']) ? $_POST['$alamat'] : '';
                ?>


                <?php
                if (empty($_GET['alert'])) {
                    echo "";
                } elseif ($_GET['alert'] == 1) {
                    ?>
                    <div class="alert alert-success">Data berhasil di simpan.</div>
                    <?php
                }
                ?>


                <div class="card">
                    <form role="form" id="form1" name="form1" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                        enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group float-label active">
                                <input type="text" name="kodeanggota" value="<?php echo $kode; ?>" readonly
                                    class="form-control">
                                <label class="form-control-label">Kode anggota</label>
                            </div>

                            <div class="form-group float-label active">
                                <input type="text" name="namaanggota" maxlength="50" class="form-control" required>
                                <label class="form-control-label">Nama anggota</label>
                            </div>

                            <div class="form-group float-label active">
                                <input type="text" name="alamat" maxlength="50" class="form-control" required>
                                <label class="form-control-label">alamat</label>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="btnSimpan" value="Save" class="btn btn-block btn-default rounded"><i
                                    class="fa fa-save"></i> Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php
} elseif ($_GET['form'] == 'edit') {
    if (isset($_GET['kodeanggota'])) {

        $query = mysqli_query($koneksidb, "SELECT * FROM anggota
										WHERE kodeanggota='$_GET[kodeanggota]'")
            or die('Query salah : ' . mysqli_error($koneksidb));
        $myData = mysqli_fetch_assoc($query);
    }
    ?>

    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <a href="home.php?open=anggota">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">keyboard_arrow_left</span>
                        </button>
                    </a>

                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Detail anggota</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">
                    <a href="home.php?open=anggota-Form&form=delete&kodeanggota=<?php echo $myData['kodeanggota']; ?>">
                        <button class="btn btn-40" type="button">
                            <span class="material-icons text-white">delete</span>
                        </button>
                    </a>
                </div>
            </div>
        </header>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">

                <?php
                if (isset($_POST['btnEdit'])) {
                    $random = (rand() % 999);

                    $kodeanggota = addslashes($_POST["kodeanggota"]);
                    $namaanggota = addslashes($_POST["namaanggota"]);

                    $query = mysqli_query($koneksidb, "UPDATE anggota SET namaanggota='$namaanggota'
													WHERE kodeanggota='$kodeanggota'")
                        or die('Insert salah : ' . mysqli_error($koneksidb));

                    if ($query) {
                        echo "<meta http-equiv='refresh' content='0; url=home.php?open=anggota-Form&form=edit&kodeanggota=$kodeanggota&alert=2'>";
                    }
                }

                # TAMPILKAN DATA KE FORM
                $dataNama = isset($_POST['namaanggota']) ? $_POST['namaanggota'] : '';
                ?>


                <?php
                if (empty($_GET['alert'])) {
                    echo "";
                } elseif ($_GET['alert'] == 2) {
                    ?>
                    <div class="alert alert-success">Data berhasil di update.</div>
                    <?php
                }
                ?>


                <div class="card">
                    <form role="form" id="form1" name="form1" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                        enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group float-label active">
                                <input type="text" name="kodeanggota" value="<?php echo $myData['kodeanggota']; ?>" readonly
                                    class="form-control">
                                <label class="form-control-label">Kode anggota</label>
                            </div>
                            <div class="form-group float-label active">
                                <input type="hidden" name="kodeanggota" value="<?php echo $myData['kodeanggota']; ?>"
                                    class="form-control">

                                <input type="text" name="namaanggota" maxlength="50"
                                    value="<?php echo $myData['namaanggota']; ?>" class="form-control" required>
                                <label class="form-control-label">Nama anggota</label>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="btnEdit" value="Save" class="btn btn-block btn-default rounded"><i
                                    class="fa fa-save"></i> Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php
}
?>