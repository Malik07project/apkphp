<main class="flex-shrink-0 main">
    <!-- Fixed navbar -->
    <header class="header">
        <div class="row">
            <div class="col-auto px-0">
                <a href="main.php?open=Dashboard">
                    <button class="btn btn-40" type="button">
                        <span class="material-icons text-white">keyboard_arrow_left</span>
                    </button>
                </a>
            </div>
            <div class="text-left col align-self-center">
                <a class="navbar-brand" href="#">
                    <h5 class="mb-0">Tambah anggota</h5>
                </a>
            </div>
            <div class="ml-auto col-auto">

            </div>
        </div>
    </header>

    <!-- page content start -->

    <div class="main-container">
        <div class="container">
            <div class="card mb-3">


                <div class="card-body">


                    <?php
                    $query = mysqli_query($koneksidb, "SELECT * FROM anggota ORDER BY kodeanggota ASC")
                        or die('Query salah : ' . mysqli_error($koneksidb));
                    $nomor = 0;
                    while ($myData = mysqli_fetch_assoc($query)) {
                        $nomor++;
                        ?>
                        <div class="media">
                            <div class="media-body">
                                <p class="small text-secondary mb-1">Kode : <?php echo $myData['kodeanggota']; ?></p>

                                <a href="?open=anggota-Form&form=edit&kodeanggota=<?php echo $myData['kodeanggota']; ?>">
                                    <h6 class="mb-1 text-default">Nama : <?php echo $myData['namaanggota']; ?></h6>
                                </a>

                                <a href="?open=anggota-Form&form=edit&kodeanggota=<?php echo $myData['kodeanggota']; ?>">
                                    <h6 class="mb-1 text-default">Alamat: <?php echo $myData['alamat']; ?></h6>
                                </a>


                            </div>

                            <div class="col-auto">
                                <a href="modul/anggota/proses.php?act=delete&kodeanggota=<?php echo $myData['kodeanggota']; ?>"
                                    onclick="return confirm('Yakin mau di hapus ?');"><i
                                        class="material-icons text-danger">delete_forever</i></a>
                            </div>
                        </div>
                        <hr>
                    <?php } ?>



                </div>

            </div>



        </div>
    </div>
</main>


<div class="footer no-bg-shadow py-3">
    <div class="row justify-content-center">
        <div class="col">

        </div>
        <div class="col">
            <div align="right"><a href="?open=anggota-Form&form=add" class="btn btn-default btn-40 rounded-circle">+</a>
            </div>
        </div>
    </div>
</div>