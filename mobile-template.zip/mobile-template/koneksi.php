<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
$server = "localhost";
$username = "root";
$password = "";
$database = "laundry";

$koneksidb = new mysqli($server, $username, $password, $database);
if ($koneksi->connect_error) {
    die('koneksi database gagal : ' . $koneksidb->connect_error);
}
?>