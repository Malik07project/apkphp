<?php
include "koneksi.php";
$username = $_POST['username'];
$password = $_POST['password'];
$enkrip = md5($password);

$query = mysqli_query($koneksidb, "select * from user 
where username='$username' and password='$enkrip' and ket='Aktif'")
    or die(mysqli_error());

$jumlah = mysqli_num_rows($query);
if ($jumlah > 0) {
    $data = mysqli_fetch_array($query);
    session_start();
    $_SESSION['iduser'] = $data['iduser'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['password'] = $data['password'];
    $_SESSION['status'] = $data['status'];
    $_SESSION['namalengkap'] = $data['namalengkap'];
    $_SESSION['ket'] = $data['ket'];

    echo "<meta http-equiv='refresh' content='0;url=main.php'>";
} else {
    echo "
  <script>alert('Username/Password salah !');
  document.location.href = './';
  </script>
  ";
}
?>